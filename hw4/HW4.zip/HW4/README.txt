This server can be instantiated in the following ways:
This is will default to port 9001: 		Python3 mcgu0156_server.py
You can specify a specific port like this:	python3 mcgu0156_server.py 9002

The server accepts the following commands: GET, PUT, POST, DELETE, and OPTIONS.

My favorite places webpage is "calendar.html".
All files should be kept in the same directory.
